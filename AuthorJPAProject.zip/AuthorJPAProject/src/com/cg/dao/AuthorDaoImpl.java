package com.cg.dao;

import java.util.List;







import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.bean.Author;
import com.cg.util.JPAUtil;

public class AuthorDaoImpl {
	EntityTransaction tran=null;
	EntityManager em=null;
	public AuthorDaoImpl()
	{
		em=JPAUtil.getEntityManager();
	}
	
	
	public Author addAuthor(Author athr)
	{
		tran=em.getTransaction();
		tran.begin();
		em.persist(athr);//for insert
		// remove for deleting
		// find for fetching based on key
		//merge for update
		tran.commit();
		return athr;
	}
	public List<Author> getAllAuthors()
	{
		String selQry="SELECT st FROM Author st";
		TypedQuery myQry=em.createQuery(selQry,Author.class);
		List<Author> athrList=myQry.getResultList();
		return athrList;
	}
	public Author getAuthorByRollNo(int authorId)
	{
		Author st=em.find(Author.class,authorId);
		return st;
	}
	public Author updateAuthorName(int athrId, String newName)
	{
		//Author st=em.find(Author.class,athrId);
		//st.setathrName(newName);
		Author st= new Author();
		st.setAuthorId(athrId);
		st.setFirstName(newName);
		
		tran.begin();
		em.merge(st);
		tran.commit();
		
		return st;
	}
	
	public Author deleteAuthor(int authorId)
	{
		Author st= em.find(Author.class, authorId);
		tran.begin();
		em.remove(st);
		tran.commit();
		return st;
	}
	
	
	

}
