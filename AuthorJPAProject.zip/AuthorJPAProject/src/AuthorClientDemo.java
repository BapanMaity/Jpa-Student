import java.util.Scanner;

import com.cg.bean.Author;
import com.cg.dao.AuthorDaoImpl;


public class AuthorClientDemo {

	public static void main(String[] args) {
		AuthorDaoImpl  athrDao=new AuthorDaoImpl();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter First Name:");
		String fnm=sc.next();

		System.out.println("Enter Middle Name:");
		String mnm=sc.next();

		System.out.println("Enter last Name:");
		String lnm=sc.next();
		System.out.println("Enter Phone Number:");
		long phoneNo=sc.nextLong();
		
		Author st= new Author();
		
		st.setFirstName(fnm);
		st.setMiddleName(mnm);
		st.setFirstName(fnm);
		st.setPhoneNo(phoneNo);
		
		Author athr=athrDao.addAuthor(st);
		System.out.println("Data Inserted in table"+athr);
	
		
		System.out.println("**********Update Author Table*************");
		Author st2=athrDao.updateAuthorName(2, "meenakshi");
		System.out.println("Updated"+st2);
		System.out.println("*********Delete Author**********");
		System.out.println("Delete 25 authorId ");
		System.out.println("Record Deleted for:"+ athrDao.deleteAuthor(25));

	}

}
