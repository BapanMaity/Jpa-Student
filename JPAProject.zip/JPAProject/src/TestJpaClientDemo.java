import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.Student;
import com.cg.dao.StudentDaoImpl;


public class TestJpaClientDemo {

	public static void main(String[] args) 
	{
		
		StudentDaoImpl  stoDao=new StudentDaoImpl();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Name:");
		String nm=sc.next();
		
		Student st= new Student();
		
		st.setStuName(nm);
		Student stu=stoDao.addStudent(st);
		System.out.println("Data Inserted in table"+stu);
		
		
		System.out.println("***Retrieve Student based on roll*****");
		Student student=stoDao.getStudentByRollNo(123);
		System.out.println(student);
		
		System.out.println("****Retrieve all datas and display********");
		List<Student> stList=stoDao.getAllStudents();
		Iterator<Student> it=stList.iterator();
		System.out.println("RollNo.\t\t\tSTUName");
		//System.out.println("**********Delete rollNo*************");
		while(it.hasNext())
		{
			Student tempStu=it.next();
			System.out.println(tempStu.getRollNo()+"\t\t"+tempStu.getStuName());
		}
		
		/*System.out.println("Delete 6 roll no ");
		System.out.println("Record Deleted for:"+ stoDao.deleteStudent(8));*/
		System.out.println("*********Update Rollno***********");
		Student st2=stoDao.updateStudentName(2, "meenakshi");
		System.out.println("Updated"+st2);
	}
}
